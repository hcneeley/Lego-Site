# LEGO Society @ Florida Poly - Deployment Instructions

This document provides instructions for deploying the LEGO Society website to Vercel.

## Prerequisites

- A [Vercel](https://vercel.com) account
- [Node.js](https://nodejs.org) installed on your local machine
- [Git](https://git-scm.com) installed on your local machine (optional, for GitHub deployment)

## Option 1: Deploy via Vercel CLI

1. Install the Vercel CLI:
   ```
   npm install -g vercel
   ```

2. Extract the `lego-society.zip` file to a directory on your computer

3. Navigate to the extracted directory in your terminal:
   ```
   cd path/to/lego-society
   ```

4. Login to Vercel:
   ```
   vercel login
   ```

5. Deploy the project:
   ```
   vercel
   ```

6. Follow the prompts in the CLI. When asked about environment variables, ensure the following are set:
   - `NEXT_PUBLIC_SUPABASE_URL`: https://upwirmiqdgzivxcceskh.supabase.co
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVwd2lybWlxZGd6aXZ4Y2Nlc2toIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDMwMDk4NTcsImV4cCI6MjA1ODU4NTg1N30.Icfa_O8lE49DAJ9i_KO_duZp2QrOg3BTDgbaySHMWns

## Option 2: Deploy via Vercel Dashboard

1. Extract the `lego-society.zip` file to a directory on your computer

2. Create a new GitHub repository and push the code to it:
   ```
   git init
   git add .
   git commit -m "Initial commit"
   git remote add origin https://github.com/yourusername/lego-society.git
   git push -u origin main
   ```

3. Go to [Vercel Dashboard](https://vercel.com/dashboard)

4. Click "Add New" > "Project"

5. Import your GitHub repository

6. Configure the project:
   - Framework Preset: Next.js
   - Root Directory: ./
   - Build Command: npm run build
   - Output Directory: .next

7. Add Environment Variables:
   - `NEXT_PUBLIC_SUPABASE_URL`: https://upwirmiqdgzivxcceskh.supabase.co
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVwd2lybWlxZGd6aXZ4Y2Nlc2toIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDMwMDk4NTcsImV4cCI6MjA1ODU4NTg1N30.Icfa_O8lE49DAJ9i_KO_duZp2QrOg3BTDgbaySHMWns

8. Click "Deploy"

## Option 3: Deploy via Drag and Drop

1. Extract the `lego-society.zip` file to a directory on your computer

2. Go to [Vercel Dashboard](https://vercel.com/dashboard)

3. Click "Add New" > "Project"

4. At the bottom of the page, look for "Import Third-Party Git Repository" and click on "Upload"

5. Drag and drop the entire lego-society folder

6. Configure the project as in Option 2 steps 6-8

## After Deployment

1. Once deployed, Vercel will provide you with a URL for your site (e.g., https://lego-society.vercel.app)

2. Test the website functionality:
   - User registration and login
   - LEGO creation uploads
   - Browsing and filtering creations
   - Mobile responsiveness

3. If you want to use a custom domain, you can configure it in the Vercel dashboard under your project settings.

## Supabase Database Setup

The SQL schema for the database is included in the `supabase/schema.sql` file. If you need to set up the database tables and policies:

1. Go to your [Supabase Dashboard](https://app.supabase.io)
2. Select your project
3. Go to the SQL Editor
4. Copy and paste the contents of `supabase/schema.sql`
5. Run the SQL commands

This will create the necessary tables, storage buckets, and access policies for the LEGO Society website.
