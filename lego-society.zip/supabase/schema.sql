-- Create profiles table for user information
CREATE TABLE IF NOT EXISTS profiles (
  id UUID REFERENCES auth.users ON DELETE CASCADE,
  email TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  PRIMARY KEY (id)
);

-- Create lego_creations table for LEGO builds
CREATE TABLE IF NOT EXISTS lego_creations (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  tags TEXT[] DEFAULT '{}',
  image_url TEXT NOT NULL,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Set up Row Level Security (RLS)
-- Enable RLS on profiles
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- Enable RLS on lego_creations
ALTER TABLE lego_creations ENABLE ROW LEVEL SECURITY;

-- Create policies for profiles
-- Users can view all profiles
CREATE POLICY "Profiles are viewable by everyone" 
  ON profiles FOR SELECT 
  USING (true);

-- Users can update only their own profile
CREATE POLICY "Users can update their own profile" 
  ON profiles FOR UPDATE 
  USING (auth.uid() = id);

-- Create policies for lego_creations
-- Anyone can view all lego creations
CREATE POLICY "Lego creations are viewable by everyone" 
  ON lego_creations FOR SELECT 
  USING (true);

-- Only authenticated users can insert lego creations
CREATE POLICY "Authenticated users can create lego creations" 
  ON lego_creations FOR INSERT 
  WITH CHECK (auth.role() = 'authenticated');

-- Users can update only their own lego creations
CREATE POLICY "Users can update their own lego creations" 
  ON lego_creations FOR UPDATE 
  USING (auth.uid() = user_id);

-- Users can delete only their own lego creations
CREATE POLICY "Users can delete their own lego creations" 
  ON lego_creations FOR DELETE 
  USING (auth.uid() = user_id);

-- Create storage bucket for lego creation images
INSERT INTO storage.buckets (id, name, public) VALUES ('lego-images', 'lego-images', true);

-- Set up storage policies
-- Anyone can view lego images
CREATE POLICY "Lego images are viewable by everyone"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'lego-images');

-- Only authenticated users can upload lego images
CREATE POLICY "Authenticated users can upload lego images"
  ON storage.objects FOR INSERT
  WITH CHECK (bucket_id = 'lego-images' AND auth.role() = 'authenticated');

-- Users can update only their own lego images
CREATE POLICY "Users can update their own lego images"
  ON storage.objects FOR UPDATE
  USING (bucket_id = 'lego-images' AND auth.uid() = owner);

-- Users can delete only their own lego images
CREATE POLICY "Users can delete their own lego images"
  ON storage.objects FOR DELETE
  USING (bucket_id = 'lego-images' AND auth.uid() = owner);
