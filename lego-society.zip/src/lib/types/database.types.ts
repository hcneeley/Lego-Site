export type User = {
  id: string;
  email: string;
  created_at: string;
};

export type LegoCreation = {
  id: string;
  title: string;
  description: string;
  tags: string[];
  image_url: string;
  user_id: string;
  created_at: string;
};

export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: User;
        Insert: Omit<User, 'id' | 'created_at'>;
        Update: Partial<Omit<User, 'id' | 'created_at'>>;
      };
      lego_creations: {
        Row: LegoCreation;
        Insert: Omit<LegoCreation, 'id' | 'created_at'>;
        Update: Partial<Omit<LegoCreation, 'id' | 'created_at'>>;
      };
    };
  };
};
