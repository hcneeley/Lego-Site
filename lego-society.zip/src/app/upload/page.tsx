'use client';

import { useSupabase } from '@/lib/supabase-provider';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import ProtectedRoute from '@/components/ProtectedRoute';
import Navbar from '@/components/Navbar';

export default function UploadPage() {
  return (
    <ProtectedRoute>
      <div className="min-h-screen bg-gray-50 lego-pattern">
        <Navbar />
        <div className="py-8">
          <UploadForm />
        </div>
      </div>
    </ProtectedRoute>
  );
}

function UploadForm() {
  const { supabase, user } = useSupabase();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [tags, setTags] = useState('');
  const [image, setImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    if (file) {
      setImage(file);
      // Create a preview URL
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    } else {
      setImage(null);
      setImagePreview(null);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    
    // Validate inputs
    if (!title || !description || !image) {
      setError('Title, description, and image are required');
      return;
    }
    
    try {
      setLoading(true);
      
      // 1. Upload image to Supabase Storage
      const fileExt = image.name.split('.').pop();
      const fileName = `${Math.random().toString(36).substring(2, 15)}.${fileExt}`;
      const filePath = `${user?.id}/${fileName}`;
      
      const { error: uploadError, data: uploadData } = await supabase.storage
        .from('lego-images')
        .upload(filePath, image);
        
      if (uploadError) throw uploadError;
      
      // 2. Get public URL for the uploaded image
      const { data: { publicUrl } } = supabase.storage
        .from('lego-images')
        .getPublicUrl(filePath);
      
      // 3. Insert record into lego_creations table
      const { error: insertError } = await supabase
        .from('lego_creations')
        .insert({
          title,
          description,
          tags: tags.split(',').map(tag => tag.trim()).filter(tag => tag !== ''),
          image_url: publicUrl,
          user_id: user?.id,
        });
        
      if (insertError) throw insertError;
      
      // 4. Redirect to home page on success
      router.push('/');
      
    } catch (error) {
      if (error instanceof Error) {
        setError(error.message);
      } else {
        setError('An error occurred while uploading your creation');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mx-auto max-w-2xl px-4">
      <div className="rounded-lg bg-white p-6 shadow-lg">
        <h1 className="mb-6 text-3xl font-bold text-blue-600">Upload Your LEGO Creation</h1>
        
        {error && (
          <div className="mb-4 rounded-md bg-red-50 p-4">
            <div className="text-sm text-red-700">{error}</div>
          </div>
        )}
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="title" className="block text-sm font-medium text-gray-700">
              Title
            </label>
            <input
              id="title"
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="lego-input"
              placeholder="My Awesome LEGO Creation"
            />
          </div>
          
          <div>
            <label htmlFor="description" className="block text-sm font-medium text-gray-700">
              Description
            </label>
            <textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={4}
              className="lego-input"
              placeholder="Describe your creation..."
            />
          </div>
          
          <div>
            <label htmlFor="tags" className="block text-sm font-medium text-gray-700">
              Tags (comma separated)
            </label>
            <input
              id="tags"
              type="text"
              value={tags}
              onChange={(e) => setTags(e.target.value)}
              className="lego-input"
              placeholder="spaceship, castle, minifigure"
            />
            <p className="mt-1 text-xs text-gray-500">
              Separate tags with commas (e.g., "spaceship, castle, minifigure")
            </p>
          </div>
          
          <div>
            <label htmlFor="image" className="block text-sm font-medium text-gray-700">
              Image
            </label>
            <input
              id="image"
              type="file"
              accept="image/*"
              onChange={handleImageChange}
              className="mt-1 block w-full text-sm text-gray-500 file:mr-4 file:rounded-md file:border-0 file:bg-blue-50 file:px-4 file:py-2 file:text-sm file:font-semibold file:text-blue-700 hover:file:bg-blue-100"
            />
          </div>
          
          {imagePreview && (
            <div className="mt-2">
              <p className="mb-2 text-sm font-medium text-gray-700">Preview:</p>
              <img 
                src={imagePreview} 
                alt="Preview" 
                className="max-h-64 rounded-md object-contain"
              />
            </div>
          )}
          
          <div>
            <button
              type="submit"
              disabled={loading}
              className="lego-button w-full"
            >
              {loading ? 'Uploading...' : 'Upload Creation'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
