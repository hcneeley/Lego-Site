'use client';

import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import Link from 'next/link';
import Navbar from '@/components/Navbar';
import { LegoCreation } from '@/lib/types/database.types';

export default function Home() {
  const [creations, setCreations] = useState<LegoCreation[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTag, setSelectedTag] = useState<string | null>(null);
  const [allTags, setAllTags] = useState<string[]>([]);

  useEffect(() => {
    fetchCreations();
  }, []);

  async function fetchCreations() {
    try {
      setLoading(true);
      
      const { data, error } = await supabase
        .from('lego_creations')
        .select('*')
        .order('created_at', { ascending: false });
        
      if (error) throw error;
      
      if (data) {
        setCreations(data as LegoCreation[]);
        
        // Extract all unique tags
        const tags = data.flatMap(creation => creation.tags || []);
        const uniqueTags = [...new Set(tags)];
        setAllTags(uniqueTags);
      }
    } catch (error) {
      console.error('Error fetching creations:', error);
    } finally {
      setLoading(false);
    }
  }

  // Filter creations based on search term and selected tag
  const filteredCreations = creations.filter(creation => {
    const matchesSearch = searchTerm === '' || 
      creation.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      creation.description.toLowerCase().includes(searchTerm.toLowerCase());
      
    const matchesTag = selectedTag === null || 
      (creation.tags && creation.tags.includes(selectedTag));
      
    return matchesSearch && matchesTag;
  });

  return (
    <div className="min-h-screen bg-gray-50 lego-pattern">
      <Navbar />
      
      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="mb-8 text-center">
          <h1 className="text-4xl font-bold text-blue-600">The LEGO Society @ Florida Poly</h1>
          <p className="mt-2 text-lg text-gray-600">Discover amazing LEGO creations from our community</p>
        </div>
        
        <div className="mb-8 flex flex-col space-y-4 sm:flex-row sm:items-center sm:justify-between sm:space-y-0">
          {/* Search input */}
          <div className="relative w-full sm:max-w-xs">
            <input
              type="text"
              placeholder="Search creations..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="lego-input pl-10"
            />
            <div className="absolute inset-y-0 left-0 flex items-center pl-3">
              <svg className="h-5 w-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>
          </div>
          
          {/* Tag filter */}
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setSelectedTag(null)}
              className={`rounded-full px-3 py-1 text-sm ${
                selectedTag === null
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              }`}
            >
              All
            </button>
            
            {allTags.map((tag) => (
              <button
                key={tag}
                onClick={() => setSelectedTag(tag)}
                className={`rounded-full px-3 py-1 text-sm ${
                  selectedTag === tag
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                {tag}
              </button>
            ))}
          </div>
        </div>
        
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <div className="h-8 w-8 animate-spin rounded-full border-b-2 border-t-2 border-blue-500"></div>
            <span className="ml-2 text-gray-600">Loading creations...</span>
          </div>
        ) : filteredCreations.length === 0 ? (
          <div className="rounded-lg bg-white p-8 text-center shadow">
            <h2 className="text-xl font-semibold text-gray-900">No creations found</h2>
            <p className="mt-2 text-gray-600">
              {searchTerm || selectedTag
                ? 'Try adjusting your search or filter'
                : 'Be the first to upload a LEGO creation!'}
            </p>
            <Link
              href="/upload"
              className="lego-button mt-4 inline-block"
            >
              Upload Creation
            </Link>
          </div>
        ) : (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 lego-grid">
            {filteredCreations.map((creation) => (
              <Link
                key={creation.id}
                href={`/creation/${creation.id}`}
                className="lego-card"
              >
                <div className="aspect-w-16 aspect-h-9 relative h-48 w-full">
                  <img
                    src={creation.image_url}
                    alt={creation.title}
                    className="h-full w-full object-cover"
                  />
                </div>
                <div className="p-4">
                  <h2 className="text-xl font-semibold text-gray-900">{creation.title}</h2>
                  <p className="mt-1 line-clamp-2 text-gray-600">{creation.description}</p>
                  
                  {creation.tags && creation.tags.length > 0 && (
                    <div className="mt-3 flex flex-wrap gap-1">
                      {creation.tags.map((tag) => (
                        <span
                          key={tag}
                          className="lego-tag"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </Link>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
