'use client';

import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useRouter } from 'next/navigation';
import Navbar from '@/components/Navbar';
import { LegoCreation } from '@/lib/types/database.types';
import Link from 'next/link';

export default function CreationDetail({ params }: { params: { id: string } }) {
  const [creation, setCreation] = useState<LegoCreation | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();

  useEffect(() => {
    fetchCreation();
  }, [params.id]);

  async function fetchCreation() {
    try {
      setLoading(true);
      
      const { data, error } = await supabase
        .from('lego_creations')
        .select('*')
        .eq('id', params.id)
        .single();
        
      if (error) throw error;
      
      if (data) {
        setCreation(data as LegoCreation);
      } else {
        setError('Creation not found');
      }
    } catch (error) {
      console.error('Error fetching creation:', error);
      setError('Error loading creation');
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 lego-pattern">
        <Navbar />
        <div className="flex min-h-[calc(100vh-4rem)] items-center justify-center">
          <div className="text-center">
            <div className="h-8 w-8 animate-spin rounded-full border-b-2 border-t-2 border-blue-500 mx-auto"></div>
            <p className="mt-2 text-gray-600">Loading creation...</p>
          </div>
        </div>
      </div>
    );
  }

  if (error || !creation) {
    return (
      <div className="min-h-screen bg-gray-50 lego-pattern">
        <Navbar />
        <div className="flex min-h-[calc(100vh-4rem)] items-center justify-center">
          <div className="max-w-md rounded-lg bg-white p-8 text-center shadow">
            <h2 className="text-xl font-semibold text-gray-900">Creation not found</h2>
            <p className="mt-2 text-gray-600">
              The LEGO creation you're looking for doesn't exist or has been removed.
            </p>
            <Link
              href="/"
              className="lego-button mt-4 inline-block"
            >
              Back to Home
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 lego-pattern">
      <Navbar />
      
      <main className="mx-auto max-w-4xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="overflow-hidden rounded-lg bg-white shadow-lg">
          <div className="relative">
            <img
              src={creation.image_url}
              alt={creation.title}
              className="h-96 w-full object-cover object-center"
            />
            <button
              onClick={() => router.push('/')}
              className="absolute left-4 top-4 rounded-full bg-white p-2 shadow hover:bg-gray-100"
            >
              <svg className="h-5 w-5 text-gray-700" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
            </button>
          </div>
          
          <div className="p-6">
            <h1 className="text-3xl font-bold text-blue-600">{creation.title}</h1>
            
            <div className="mt-4">
              <p className="whitespace-pre-wrap text-gray-700">{creation.description}</p>
            </div>
            
            {creation.tags && creation.tags.length > 0 && (
              <div className="mt-6">
                <h2 className="text-sm font-medium text-gray-500">Tags</h2>
                <div className="mt-2 flex flex-wrap gap-2">
                  {creation.tags.map((tag) => (
                    <span
                      key={tag}
                      className="lego-tag"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            )}
            
            <div className="mt-6 border-t border-gray-200 pt-6">
              <div className="flex flex-col sm:flex-row items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500">
                    Uploaded on {new Date(creation.created_at).toLocaleDateString()}
                  </p>
                </div>
                <Link
                  href="/"
                  className="lego-button mt-4 sm:mt-0"
                >
                  Back to Gallery
                </Link>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
